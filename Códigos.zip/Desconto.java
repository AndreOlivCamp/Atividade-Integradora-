package src;

public interface Desconto {
    double aplicar(double valor);
}

class SemDescoonto implements Desconto {
    public double aplicar(double valor) { return valor; }
}

class DescontoEstudande implements Desconto {
    public double aplicar(double valor) { return valor * 0.90; }
}
