package src;

import java.util.ArrayList;
import java.util.List;

// 1. A Interface do Comprovante
interface Comprovante {
    String gerar(Aluno aluno, Curso curso, double valor);
}

// 2. Implementação 1: Comprovante em formato de Texto Completo
class ComprovanteTexto implements Comprovante {
    @Override
    public String gerar(Aluno aluno, Curso curso, double valor) {
        return "--- COMPROVANTE OFICIAL ---\n" +
                "Aluno: " + aluno.getNome() + "\n" +
                "Curso: " + curso.getTitulo() + "\n" +
                "Valor Pago: R$ " + valor + "\n" +
                "--------------------------";
    }
}

// 3. Implementação 2: Comprovante em formato Resumido
class ComprovanteResumido implements Comprovante {
    @Override
    public String gerar(Aluno aluno, Curso curso, double valor) {
        return "[Resumo] " + aluno.getNome() + " | " + curso.getTitulo() + " | R$ " + valor;
    }
}

// 4. O Criador Abstrato (fornecido por você)
abstract class CriadorComprovante {
    public abstract Comprovante criar();

    public String emitir(Aluno aluno, Curso curso, double valor) {
        return criar().gerar(aluno, curso, valor);
    }
}

// 5. Novo: Criador Concreto para o Comprovante Texto
class CriadorTexto extends CriadorComprovante {
    @Override
    public Comprovante criar() {
        return new ComprovanteTexto(); // Cria e devolve a versão detalhada
    }
}

// 6. Novo: Criador Concreto para o Comprovante Resumido
class CriadorResumido extends CriadorComprovante {
    @Override
    public Comprovante criar() {
        return new ComprovanteResumido(); // Cria e devolve a versão resumida
    }
}