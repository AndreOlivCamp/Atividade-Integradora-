package src;

public class SistemaLegado {
    public void registrarEmCentavos(int centavos) {
        System.out.println("Legado registrou: " + centavos + "centavos");
    }
}

interface RegistrarPagamento{
    void registrar(double reais);
}

class AdaptadorPagamento implements RegistrarPagamento {
    private final SistemaLegado legado;

    public AdaptadorPagamento(SistemaLegado legado) {
        this.legado = legado;
    }

    public void registrar(double reais) {
        int centavos = (int) Math.round(reais * 100);
        legado.registrarEmCentavos(centavos);
    }
}
