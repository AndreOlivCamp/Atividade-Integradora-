package src;

public class MainComprovante {
    public static void main(String[] args) {
        // Criando dados de teste (usando as classes Curso e Aluno que fizemos antes)
        Curso curso = new Curso("Java Avançado", 200.0);
        Aluno aluno = new Aluno("Carlos");

        // Usando o criador de texto completo
        CriadorComprovante criador1 = new CriadorTexto();
        String resultado1 = criador1.emitir(aluno, curso, 200.0);
        System.out.println(resultado1);

        System.out.println("\n---------------------------\n");

        // Usando o criador resumido
        CriadorComprovante criador2 = new CriadorResumido();
        String resultado2 = criador2.emitir(aluno, curso, 200.0);
        System.out.println(resultado2);
    }

    public static class MainObservador {
        public static void main(String[] args) {
            // 1. Criamos os nossos "observadores" (quem vai receber)
            ObservadorMatricula email = new src.Observer.AvisoEmail();
            ObservadorMatricula auditoria = new src.Observer.Auditoria();

            // 2. Simulando uma ação que gera uma mensagem
            String mensagemMatricula = "Matrícula realizadan com sucesso no curso de Java";

            // 3. Disparando os avisos para cada observador
            System.out.println("--- Notificando sistemas ---");

            email.atualizar(mensagemMatricula);
            auditoria.atualizar(mensagemMatricula);
        }
    }
}
