package src;

import java.util.ArrayList;
import java.util.List;
interface Desconto { double aplicar(double valor); }
class SemDesconto implements src.Desconto { public double aplicar(double valor) { return valor; } }
class DescontoEstudante implements src.Desconto { public double aplicar(double valor) { return
        valor * 0.90; } }
final class Configuracao {
    private static final Configuracao INSTANCIA = new Configuracao();
    private final String nome = "Sistema Acadêmico";
    private Configuracao() {}
    public static Configuracao getInstancia() { return INSTANCIA; }
    public String getNome() { return nome; }
}
class Aluno {
    private final String nome;
    private final List<Curso> cursos = new ArrayList<>();
    public Aluno(String nome) {
        if (nome == null || nome.isBlank()) throw new IllegalArgumentException("Nome
                inválido");
        this.nome = nome;
    }
    public String getNome() { return nome; }
    public void adicionarCurso(Curso curso) { if (curso == null) throw new
            IllegalArgumentException("Curso inválido"); cursos.add(curso); }
    public int getQuantidadeCursos() { return cursos.size(); }
}
class Curso {
    private final String titulo;
    private final double preco;
    public Curso(String titulo, double preco) {
        if (titulo == null || titulo.isBlank() || preco <= 0) throw new
                IllegalArgumentException("Dados inválidos");
        this.titulo = titulo; this.preco = preco;
    }
    public String getTitulo() { return titulo; }
    public double getPreco() { return preco; }
}
interface ObservadorMatricula { void atualizar(String mensagem); }
class AvisoEmail implements ObservadorMatricula {
    public void atualizar(String mensagem) { System.out.println("E-mail: " + mensagem); }
}
class Auditoria implements ObservadorMatricula {
    public void atualizar(String mensagem) { System.out.println("Auditoria: " + mensagem); }
}
interface Comprovante { String gerar(Aluno aluno, Curso curso, double valor); }
class ComprovanteTexto implements Comprovante {
    public String gerar(Aluno aluno, Curso curso, double valor) {
        return "Matrícula: " + aluno.getNome() + " / " + curso.getTitulo() + " / R$ " + valor;
    }
}
class ComprovanteResumido implements Comprovante {
    public String gerar(Aluno aluno, Curso curso, double valor) {
        return aluno.getNome() + " - R$ " + valor;
    }
}
abstract class CriadorComprovante {
    public abstract Comprovante criar();
    public String emitir(Aluno aluno, Curso curso, double valor) {
        return criar().gerar(aluno, curso, valor);
    }
}
class CriadorTexto extends CriadorComprovante {
    public Comprovante criar() { return new ComprovanteTexto(); }
}
class CriadorResumido extends CriadorComprovante {
    public Comprovante criar() { return new ComprovanteResumido(); }
}
class SistemaLegado {
    public void registrarEmCentavos(int centavos) { System.out.println("Legado registrou: " +
            centavos + " centavos"); }
}
interface RegistradorPagamento { void registrar(double reais); }
class AdaptadorPagamento implements RegistradorPagamento {
    private final SistemaLegado legado;
    public AdaptadorPagamento(SistemaLegado legado) { this.legado = legado; }
    public void registrar(double reais) { legado.registrarEmCentavos((int) Math.round(reais *
            100)); }
}
class ServicoMatricula {
    private final src.Desconto desconto;
    private final RegistradorPagamento pagamento;
    private final List<ObservadorMatricula> observadores = new ArrayList<>();
    public ServicoMatricula(src.Desconto desconto, RegistradorPagamento pagamento) {
        this.desconto = desconto; this.pagamento = pagamento;

        public void inscrever(ObservadorMatricula observador) { observadores.add(observador); }
        public double matricular(Aluno aluno, Curso curso) {
            double total = desconto.aplicar(curso.getPreco());
            pagamento.registrar(total);
            aluno.adicionarCurso(curso);
            for (ObservadorMatricula o : observadores) o.atualizar(aluno.getNome() + " matriculado
                    em " + curso.getTitulo());
            return total;
        }
    }
    class FachadaAcademica {
        private final ServicoMatricula servico;
        private final CriadorComprovante criador;
        public FachadaAcademica(ServicoMatricula servico, CriadorComprovante criador) {
            this.servico = servico; this.criador = criador;
        }
        public String matricularEEmitir(Aluno aluno, Curso curso) {
            double total = servico.matricular(aluno, curso);
            return criador.emitir(aluno, curso, total);
        }
    }

    public class Main {
        public static void main(String[] args) {
            System.out.println(Configuracao.getInstancia().getNome());
            Aluno aluno = new Aluno("Ana");
            Curso curso = new Curso("Java", 200.0);
            ServicoMatricula servico = new ServicoMatricula(new DescontoEstudante(), new
                    AdaptadorPagamento(new SistemaLegado()));
            servico.inscrever(new AvisoEmail());
            servico.inscrever(new Auditoria());
            FachadaAcademica fachada = new FachadaAcademica(servico, new CriadorTexto());
            System.out.println(fachada.matricularEEmitir(aluno, curso));
            System.out.println("Cursos do aluno: " + aluno.getQuantidadeCursos());
        }
    }