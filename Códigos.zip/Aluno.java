package src;

import java.util.ArrayList;
import java.util.List;

public class Aluno {
    private final String nome;
    private final List<Curso> cursos;

    // Construtor: valida o nome e inicializa a lista de cursos vazia
    public Aluno(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome inválida");
        }
        this.nome = nome;
        this.cursos = new ArrayList<>();
    }

    //Método para matricular o aluno em um curso
    public void adicionarCurso(Curso curso) {
        if (curso != null){
            this.cursos.add(curso);
        }
    }

    // Retorna o nome do aluno
    public String getNome() {
        return nome;
    }

    // Retorna quantos cursos o aluno está fazendo
    public int getQuantidadeCursos(){
        return cursos.size();
    }
}
