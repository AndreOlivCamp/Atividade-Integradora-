package src;

public class Main {
    public static void main(String[] args) {
        // 1. Criando um curso
        Curso meuCurso = new Curso("Java para Iniciantes", 150.0);

        // 2. Criando um aluno
        Aluno meuAluno = new Aluno("Maria");

        // 3. Matriculando a Maria no curso
        meuAluno.adicionarCurso(meuCurso);

        // 4. Imprimindo os resultados no console
        System.out.println("src.Aluno: " + meuAluno.getNome());
        System.out.println("Quantidade de cursos: " + meuAluno.getQuantidadeCursos());
        System.out.println("Nome do curso matriculado: " + meuCurso.getTitulo());
        System.out.println("Preço do curso: R$ " + meuCurso.getPreco());
    }
}
